-- Run this in Supabase SQL Editor.
-- Your existing customers, sales, expenses and shop_profiles tables are retained.

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  sku text,
  price numeric(12,2) not null default 0 check (price >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

drop policy if exists "Users manage own products" on public.products;
create policy "Users manage own products"
on public.products
for all
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create index if not exists products_user_id_idx on public.products(user_id);
create index if not exists customers_user_id_idx on public.customers(user_id);
create index if not exists sales_user_id_idx on public.sales(user_id);
create index if not exists expenses_user_id_idx on public.expenses(user_id);
