import { useEffect, useMemo, useState } from 'react'
import {
  LayoutDashboard, Package, Users, ReceiptText, Wallet, LogOut,
  Plus, Trash2, Menu, X, TrendingUp, Boxes, IndianRupee, RefreshCw
} from 'lucide-react'
import { configReady, supabase } from './supabase'

const nav = [
  ['dashboard', 'Dashboard', LayoutDashboard],
  ['products', 'Products', Package],
  ['customers', 'Customers', Users],
  ['sales', 'Sales', ReceiptText],
  ['expenses', 'Expenses', Wallet],
]
const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(n || 0))

function Auth({ onAuthed }) {
  const [mode, setMode] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')

  async function submit(e) {
    e.preventDefault()
    setBusy(true); setMessage('')
    try {
      const result = mode === 'login'
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password })
      if (result.error) throw result.error
      if (result.data.session) onAuthed(result.data.session)
      else setMessage('Account created. Check your email to confirm it, then sign in.')
    } catch (err) { setMessage(err.message || 'Could not authenticate.') }
    finally { setBusy(false) }
  }

  return <main className="auth-wrap">
    <section className="auth-card">
      <div className="brand-mark">B</div>
      <p className="eyebrow">SHOP MANAGEMENT</p>
      <h1>BASU Shop Manager</h1>
      <p className="muted">Your shop, organized in one place.</p>
      <div className="switcher">
        <button className={mode === 'login' ? 'selected' : ''} onClick={() => {setMode('login');setMessage('')}}>Sign in</button>
        <button className={mode === 'signup' ? 'selected' : ''} onClick={() => {setMode('signup');setMessage('')}}>Create account</button>
      </div>
      <form onSubmit={submit} className="form-stack">
        <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email" /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength="6" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>
        {message && <div className="notice">{message}</div>}
        <button className="primary full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
      </form>
      <p className="tiny muted">Your shop data is protected by Supabase Row Level Security.</p>
    </section>
  </main>
}

function ModalForm({ title, fields, onClose, onSave }) {
  const [values, setValues] = useState({})
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  async function submit(e) {
    e.preventDefault(); setBusy(true); setError('')
    try { await onSave(values); onClose() }
    catch (err) { setError(err.message || 'Could not save record.') }
    finally { setBusy(false) }
  }
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}>
    <form className="modal form-stack" onSubmit={submit}>
      <div className="modal-head"><h2>{title}</h2><button type="button" className="icon-btn" onClick={onClose}><X size={19}/></button></div>
      {fields.map(f=><label key={f.name}>{f.label}
        {f.type === 'select'
          ? <select required={f.required !== false} value={values[f.name] ?? f.defaultValue ?? ''} onChange={e=>setValues({...values,[f.name]:e.target.value})}>{f.options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select>
          : <input required={f.required !== false} type={f.type || 'text'} min={f.min} step={f.step} placeholder={f.placeholder || ''} value={values[f.name] ?? ''} onChange={e=>setValues({...values,[f.name]:e.target.value})} />}
      </label>)}
      {error && <div className="notice error">{error}</div>}
      <button className="primary full" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
    </form>
  </div>
}

export default function App() {
  const [session, setSession] = useState(null)
  const [checking, setChecking] = useState(true)
  const [tab, setTab] = useState('dashboard')
  const [mobileNav, setMobileNav] = useState(false)
  const [data, setData] = useState({ products: [], customers: [], sales: [], expenses: [] })
  const [loading, setLoading] = useState(false)
  const [modal, setModal] = useState(false)
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (!supabase) { setChecking(false); return }
    supabase.auth.getSession().then(({data}) => { setSession(data.session); setChecking(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next))
    return () => listener.subscription.unsubscribe()
  }, [])

  async function loadData() {
    if (!session?.user) return
    setLoading(true)
    const tables = ['products','customers','sales','expenses']
    const results = await Promise.all(tables.map(t => supabase.from(t).select('*').order('created_at', {ascending:false}).limit(200)))
    const next = {}
    for (let i=0;i<tables.length;i++) {
      if (results[i].error) { setToast(results[i].error.message); next[tables[i]] = [] }
      else next[tables[i]] = results[i].data || []
    }
    setData(next); setLoading(false)
  }

  useEffect(() => { loadData() }, [session?.user?.id])

  const totals = useMemo(() => ({
    sales: data.sales.reduce((s,r)=>s+Number(r.total_amount||0),0),
    expenses: data.expenses.reduce((s,r)=>s+Number(r.amount||0),0),
    products: data.products.length,
    customers: data.customers.length,
  }), [data])

  const definitions = {
    products: { title:'Add product', table:'products', fields:[
      {name:'name',label:'Product name'}, {name:'sku',label:'SKU (optional)',required:false},
      {name:'price',label:'Selling price (₹)',type:'number',min:'0',step:'0.01'},
      {name:'stock_quantity',label:'Opening stock',type:'number',min:'0',step:'1'}
    ], map:v=>({...v,price:Number(v.price),stock_quantity:Number(v.stock_quantity||0)}) },
    customers: { title:'Add customer', table:'customers', fields:[
      {name:'name',label:'Customer name'}, {name:'phone',label:'Phone number',required:false},
      {name:'credit_balance',label:'Opening credit (₹)',type:'number',min:'0',step:'0.01',required:false}
    ], map:v=>({...v,credit_balance:Number(v.credit_balance||0)}) },
    sales: { title:'Record sale', table:'sales', fields:[
      {name:'total_amount',label:'Sale amount (₹)',type:'number',min:'0.01',step:'0.01'},
      {name:'payment_method',label:'Payment method',type:'select',options:[{value:'cash',label:'Cash'},{value:'upi',label:'UPI'},{value:'card',label:'Card'},{value:'credit',label:'Customer credit'}]}
    ], map:v=>({...v,total_amount:Number(v.total_amount)}) },
    expenses: { title:'Add expense', table:'expenses', fields:[
      {name:'description',label:'Description'}, {name:'amount',label:'Amount (₹)',type:'number',min:'0.01',step:'0.01'}
    ], map:v=>({...v,amount:Number(v.amount)}) },
  }

  async function addRecord(values) {
    const def = definitions[tab]
    const payload = {...def.map(values), user_id:session.user.id}
    const {error} = await supabase.from(def.table).insert(payload)
    if (error) throw error
    await loadData(); setToast('Saved successfully')
  }
  async function deleteRecord(table, id) {
    if (!window.confirm('Delete this record? This cannot be undone.')) return
    const {error} = await supabase.from(table).delete().eq('id',id)
    if (error) setToast(error.message)
    else { await loadData(); setToast('Record deleted') }
  }

  if (!configReady) return <main className="setup-wrap"><section className="setup-card">
    <div className="brand-mark">B</div><h1>Connect BASU to Supabase</h1>
    <p>Create a file named <code>.env</code> in the project root by copying <code>.env.example</code>, then enter your Supabase Project URL and publishable key.</p>
    <p className="muted">Never use your <code>sb_secret_…</code> key in this app.</p>
  </section></main>
  if (checking) return <div className="loading-screen">Loading BASU Shop Manager…</div>
  if (!session) return <Auth onAuthed={setSession} />

  const rows = data[tab] || []
  const def = definitions[tab]
  const title = nav.find(n=>n[0]===tab)?.[1] || 'Dashboard'

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'open':''}`}>
      <div className="side-brand"><div className="brand-mark small">B</div><div><strong>BASU</strong><span>SHOP MANAGER</span></div><button className="icon-btn mobile-close" onClick={()=>setMobileNav(false)}><X/></button></div>
      <p className="nav-label">WORKSPACE</p>
      {nav.map(([id,label,Icon])=><button key={id} className={`nav-item ${tab===id?'active':''}`} onClick={()=>{setTab(id);setMobileNav(false)}}><Icon size={18}/>{label}</button>)}
      <div className="sidebar-bottom"><div className="user-chip"><span className="avatar">{session.user.email?.[0]?.toUpperCase()||'U'}</span><span className="user-email">{session.user.email}</span></div><button className="nav-item" onClick={()=>supabase.auth.signOut()}><LogOut size={18}/>Sign out</button></div>
    </aside>
    {mobileNav && <div className="scrim" onClick={()=>setMobileNav(false)} />}
    <main className="main-area">
      <header className="topbar"><button className="icon-btn menu-toggle" onClick={()=>setMobileNav(true)}><Menu/></button><div><p className="eyebrow">YOUR BUSINESS</p><h1>{title}</h1></div><button className="icon-btn refresh" onClick={loadData} title="Refresh"><RefreshCw size={18}/></button></header>
      <div className="content">
        {toast && <button className="toast" onClick={()=>setToast('')}>{toast} ×</button>}
        {tab==='dashboard' ? <>
          <div className="welcome"><div><h2>Welcome to your shop</h2><p className="muted">Here is your business overview.</p></div><span className="live-pill">● CLOUD CONNECTED</span></div>
          <div className="stats-grid">
            <Stat icon={IndianRupee} label="Total sales" value={money(totals.sales)} />
            <Stat icon={Wallet} label="Total expenses" value={money(totals.expenses)} />
            <Stat icon={Boxes} label="Products" value={totals.products} />
            <Stat icon={Users} label="Customers" value={totals.customers} />
          </div>
          <section className="panel"><div className="panel-head"><div><h3>Business summary</h3><p className="muted">Based on records currently stored</p></div><TrendingUp className="accent-icon"/></div>
            <div className="summary-line"><span>Recorded sales</span><strong>{money(totals.sales)}</strong></div>
            <div className="summary-line"><span>Recorded expenses</span><strong>{money(totals.expenses)}</strong></div>
            <div className="summary-line"><span>Estimated difference</span><strong className={totals.sales-totals.expenses>=0?'positive':'negative'}>{money(totals.sales-totals.expenses)}</strong></div>
            <p className="tiny muted">This is a simple sales-minus-expenses estimate, not a finalized accounting profit.</p>
          </section>
        </> : <section className="panel">
          <div className="panel-head"><div><h3>{title}</h3><p className="muted">{rows.length} records</p></div><button className="primary" onClick={()=>setModal(true)}><Plus size={17}/> Add {tab.slice(0,-1)}</button></div>
          {loading ? <p className="muted">Loading records…</p> : rows.length===0 ? <div className="empty"><Package size={30}/><strong>No records yet</strong><span>Add your first {tab.slice(0,-1)} to get started.</span></div> :
            <div className="table-wrap"><table><thead><tr>{(tab==='products'?['Name','SKU','Price','Stock']:tab==='customers'?['Name','Phone','Credit']:tab==='sales'?['Amount','Payment','Date']:['Description','Amount','Date']).map(h=><th key={h}>{h}</th>)}<th></th></tr></thead>
              <tbody>{rows.map(r=><tr key={r.id}>
                {tab==='products' && <><td>{r.name}</td><td>{r.sku||'—'}</td><td>{money(r.price)}</td><td>{r.stock_quantity}</td></>}
                {tab==='customers' && <><td>{r.name}</td><td>{r.phone||'—'}</td><td>{money(r.credit_balance)}</td></>}
                {tab==='sales' && <><td>{money(r.total_amount)}</td><td><span className="tag">{r.payment_method||'—'}</span></td><td>{new Date(r.created_at).toLocaleDateString('en-IN')}</td></>}
                {tab==='expenses' && <><td>{r.description}</td><td>{money(r.amount)}</td><td>{new Date(r.created_at).toLocaleDateString('en-IN')}</td></>}
                <td><button className="icon-btn danger" title="Delete" onClick={()=>deleteRecord(def.table,r.id)}><Trash2 size={16}/></button></td>
              </tr>)}</tbody></table></div>}
        </section>}
      </div>
    </main>
    {modal && <ModalForm title={def.title} fields={def.fields} onClose={()=>setModal(false)} onSave={addRecord}/>}
  </div>
}

function Stat({icon:Icon,label,value}) {
  return <div className="stat-card"><div className="stat-icon"><Icon size={19}/></div><p>{label}</p><strong>{value}</strong></div>
}
