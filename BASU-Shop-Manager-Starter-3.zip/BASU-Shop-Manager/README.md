# BASU Shop Manager

Starter application for a responsive shop-management website and Android app.

## Included
- Supabase email/password authentication
- Dashboard totals
- Products, customers, sales and expenses
- Row-level security for products (existing tables already have RLS policies)
- Responsive mobile/desktop layout
- Capacitor Android project setup

## 1. Requirements
Install Node.js LTS and (for Android builds) Android Studio on your computer.

## 2. Configure Supabase
1. In Supabase SQL Editor, run `database-setup.sql`.
2. In this project folder, copy `.env.example` to `.env`.
3. Set:
   - `VITE_SUPABASE_URL` to your project URL
   - `VITE_SUPABASE_ANON_KEY` to your `sb_publishable_...` key
4. Never use an `sb_secret_...` key in this frontend project.
5. In Supabase Authentication settings, configure your Site URL and allowed redirect URLs for your local and deployed website origins. For local development, add `http://localhost:5173`.

## 3. Run the website
```bash
npm install
npm run dev
```
Open the local URL shown by Vite, normally `http://localhost:5173`.

## 4. Build Android
Install Android Studio and its Android SDK first.
```bash
npm run android:add
npm run android:sync
npm run android:open
```
In Android Studio, wait for Gradle sync, then use Build > Build Bundle(s) / APK(s) > Build APK(s).
For later code changes, run `npm run android:sync` again before building.

## 5. Deploy website
Run `npm run build`, then deploy the `dist` folder to a static hosting provider. Add the deployed website origin to Supabase Auth redirect URLs. Set the same two VITE_ environment variables in the hosting provider.

## Important scope and next stage
This is a functional starter, not yet a finished commercial POS. Product stock is currently stored and displayed, but sales do not yet automatically deduct stock. Customer credit is recorded as an opening balance, but credit payments/ledger are not yet implemented. Subscription billing, payment gateway verification, invoice PDFs, audit logs, and automated backups must be added before commercial launch. Payment gateway secret credentials must only be stored on a trusted server/edge function, never in the browser or APK.
